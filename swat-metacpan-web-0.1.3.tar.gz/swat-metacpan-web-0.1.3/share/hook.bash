export latest_rs_age

